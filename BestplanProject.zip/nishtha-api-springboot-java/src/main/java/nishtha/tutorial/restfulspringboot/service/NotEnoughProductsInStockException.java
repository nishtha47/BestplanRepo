package nishtha.tutorial.restfulspringboot.service;

public class NotEnoughProductsInStockException extends Exception {

}
