package nishtha.tutorial.restfulspringboot.service;


import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import nishtha.tutorial.restfulspringboot.domain.Product;

public interface PlanItemcheckoutService {

    
    BigDecimal getTotal();
    
}